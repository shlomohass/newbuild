<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$Lang = array( 
    "lang" => "English",
    "dic"  => array(
    //GENERAL:
        "gen_title_prefix"              => "ShareMaster | ",
        "gen_title_for_display"         => "ShareMaster",
        
    //Login page:
        "login_title"                   => "Login",
        "login_desc"                    => "",
        "login_keys"                    => "",
        
    //App Page:
        "home_title"                    => "ShareMaster Home",
        "home_desc"                     => "",
        "home_keys"                     => "",
        
    //Admin Pages:
        "home_title"                    => "ShareMaster Home",
        "home_desc"                     => "",
        "home_keys"                     => ""
    ),
    
    "js" => array(
        "script-frontend" => array(
            //Setting plan:
            "condirm_plan_delete_title"             => "Confirm delete operation"
        ),
        "script-login" => array(

        ),
        "script-admin" => array(

        )
    )
);
